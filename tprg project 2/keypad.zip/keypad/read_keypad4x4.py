#!/usr/bin/env python3
# Read a 4x4 keypad using CircuitPython MatrixKeypad + Blinka
# Prints a list of all keys pressed at the moment.

# Import libraries
import time

import digitalio
import board
import adafruit_matrixkeypad

col_pins = (board.D17, board.D27, board.D22, board.D5)
row_pins = (board.D18, board.D23, board.D24, board.D25)

rows = []
cols = []
for row_pin in row_pins:
	rows.append(digitalio.DigitalInOut(row_pin))
for col_pin in col_pins:
	cols.append(digitalio.DigitalInOut(col_pin))
keys = ((0, 1, 2, 3),
        (4, 5, 6, 7),
        (8, 9, 'A', 'B'),
        ('C', 'D', 'E', 'F'))

keypad = adafruit_matrixkeypad.Matrix_Keypad(rows, cols, keys)


while True:
    kp = keypad.pressed_keys
    if kp:
        print("Pressed:", kp)

    time.sleep(0.1)  # slow down so that we can see it work.
