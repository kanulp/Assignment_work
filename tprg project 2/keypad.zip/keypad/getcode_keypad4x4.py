#!/usr/bin/env python3
# read a numeric code from a 4x4 keypad using the
# CircuitPython MatrixKeypad and Blinka modules.
# The keypad reader is split off into a separate thread
# so that the application remains responsive even if
# it is waiting for the passcode.


# Import modules
import threading
import queue
import time

# CircuitPython modules (requires adafruit-blinka module)
import digitalio
import board
import adafruit_matrixkeypad

def keypad_worker(que):
    code = ""  # entered code, initially empty
    no_key = True  # state variable 
    while True:
        kp = keypad.pressed_keys
        if no_key:
            if kp:  # Key was pressed, process the key value
                if kp[0] in "0123456789":
                    code.append(kp[0])
                elif kp[0] == 'F':
                    que.put_nowait(code)
                else:
                    pass # ignore "ABCDE" keys
                no_key = False
        else:
            if not kp:
                no_key = True
    

# Define the keypad: pin numbering, rows, columns and key values
col_pins = (board.D17, board.D27, board.D22, board.D5)
row_pins = (board.D18, board.D23, board.D24, board.D25)
rows = []
cols = []
for row_pin in row_pins:
    rows.append(digitalio.DigitalInOut(row_pin))
for col_pin in col_pins:
    cols.append(digitalio.DigitalInOut(col_pin))
keys = (('0', '1', '2', '3'),
        ('4', '5', '6', '7'),
        ('8', '9', 'A', 'B'),
        ('C', 'D', 'E', 'F'))
keypad = adafruit_matrixkeypad.Matrix_Keypad(rows, cols, keys)

# Define the queue and start a thread to read codes from the keypad
input_q = queue.Queue()  # Queue from thread1 to main
thread1 = threading.Thread(target=keypad_worker, args=(input_q,))
thread1.start()

if __name__ == "__main__":
    while True:
        while not input_q.empty():
            print(input_q.get())
        time.sleep(0.1)
