#!/usr/bin/env python3
# Read a 4x4 keypad using CircuitPython MatrixKeypad + Blinka
# Return only a single key event, waits until keypad released before
# returning a new key. Print only the first key in the list returned
# by keypad.pressed_keys

# Import libraries
import time

import digitalio
import board
import adafruit_matrixkeypad

col_pins = (board.D17, board.D27, board.D22, board.D5)
row_pins = (board.D18, board.D23, board.D24, board.D25)

rows = []
cols = []
for row_pin in row_pins:
	rows.append(digitalio.DigitalInOut(row_pin))
for col_pin in col_pins:
	cols.append(digitalio.DigitalInOut(col_pin))
keys = (('0', '1', '2', '3'),
        ('4', '5', '6', '7'),
        ('8', '9', 'A', 'B'),
        ('C', 'D', 'E', 'F'))

keypad = adafruit_matrixkeypad.Matrix_Keypad(rows, cols, keys)

no_key = True  # simple state machine state variable
while True:
    kp = keypad.pressed_keys
    if no_key:
        if kp:
            print("Pressed:", kp[0])
            no_key = False
    else:
        if not kp:
            no_key = True

    time.sleep(0.1)  # Slow down so we can see it in action
