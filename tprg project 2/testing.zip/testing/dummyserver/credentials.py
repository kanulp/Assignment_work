# Example credentials file to be imported
#
# In your server program, place the following import statement near the top.
# from credentials import credentials

# edit for the real user IDs in your project
credentials = {
    "ali": ["00123", "crypto"],
    "bianca": ["22456", "secret"],
    "fred": ["98765", "noclue"]
    }
