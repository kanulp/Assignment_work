# dummyclient.py -- test client for TPRG2131 F2019 Project 2
# Transmit a sequence of AUTHREQ and LOOKUPREQ messages to a
# server and print out the resulting REPLY messages. This is
# used to test the server in the Project 2 communication system.
#
# Run this from PowerShell (Windows) or bash (Linux)
#
# Client-server examples based on tutorial by Nathan Jennings
#  https://realpython.com/python-sockets/
#

import json  # serialize data 
import socket  # low level networking (Berkeley sockets)

# During class time, a test server will be running on tau.durhamcollege.org
# otherwise, set up a server on your own PC or your partner's
HOST_TAU = "205.211.181.143"  # tau.durhamcollege.org

HOST = HOST_TAU  # The server's address
PORT = 8082        # The port used by the server

# Define the message dictionaries and sequence through them 
messages = [
            {
            "msgtype": "AUTHREQ",  # AuthReq good
            "userid": "ali",
            "passcode": "00123"
            },
            {
            "msgtype": "AUTHREQ",  # AuthReq bad
            "userid": "fred",
            "passcode": "00123"
            },
            {
            "msgtype": "LOOKUPREQ",  # LookupReq good
            "userid": "ali",
            "lookup": "bianca"
            },
            {
            "msgtype": "LOOKUPREQ",  # LookupReq bad
            "userid": "fred",        # requestor not logged in
            "lookup": "bianca"
            },
            {
            "msgtype": "LOOKUPREQ",  # LookupReq bad
            "userid": "ali",         # destination not logged in
            "lookup": "charlie"
            }
        ]
        
for message in messages:
    print("\nmessage is\n    ", message)
    json_encoded = json.dumps(message)
    print("encoded is\n    ", json_encoded)

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((HOST, PORT))
        send_data = json_encoded.encode("utf-8")  # convert Unicode str to bytearray
        sock.sendall(send_data)
        recv_data = sock.recv(1024)
        print("Received is\n    ", recv_data.decode("utf-8"))
