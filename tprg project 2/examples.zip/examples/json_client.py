# Simple echo client
# Based on tutorial by Nathan Jennings
#  https://realpython.com/python-sockets/
#
# The client will send a number of strings to the server and receive them back.

import json  # serialize data 
import socket  # the socket module

HOST = "127.0.0.1"  # The server's hostname or IP address
PORT = 8082        # The port used by the server

# Define the dictionary
user = {"first": "Fred",
        "last": "Flintstone"
        }
print("user is\n    ", user)
json_encoded = json.dumps(user)
print("\nencoded is\n    ", json_encoded)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    sock.connect((HOST, PORT))
    send_data = json_encoded.encode("utf-8")  # convert Unicode str to bytearray
    sock.sendall(send_data)
    recv_data = sock.recv(1024)
    print("Received:", recv_data.decode("utf-8"))
