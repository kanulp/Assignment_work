# Simple echo server to demonstrate the socket interface
# Based on tutorial by Nathan Jennings
#  https://realpython.com/python-sockets/
#
# The server accepts connections and echoes messages back to the client.

import json
import socket

# Using the loopback interface address, a.k.a. localhost
# The port range 8080 to 8089 is generally available
HOST = "127.0.0.1"  # loopback address, a.k.a. localhost
PORT = 8082  # integer, range 1 to 65,535; lower 1024 values reserved

# Create a new socket for address family IPv4, TCP protocol (Stream)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Bind that socket to a specific address and port number on the machine
sock.bind((HOST, PORT))
# This socket is configured for listening for incoming connections
sock.listen()
# wait for a connection request and accept it.
# when the connection is made, conn is a connection object and
# addr is the (IP address, port) of the client that is connecting.
conn, addr = sock.accept()

# The with statement creates a context
# conn will be closed when the context ends; we don’t need conn.close()
with conn:
    print("Connection from", addr)
    while True:
        data = conn.recv(1024)
        if not data:
            break
        recv_string = data.decode()
        print("Data:", recv_string)
        recv_dict = json.loads(recv_string)
        for k in recv_dict:
            print(k, recv_dict[k])
        conn.sendall(data)

# Done!
sock.close() # (Actually should use another with statement!)
print("Socket closed. Bye!")