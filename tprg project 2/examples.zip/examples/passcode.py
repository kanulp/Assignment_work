"""passcode.py -- demonstrate passcode hashing and comparing.

TPRG 2131 Fall 2019
Louis Bertrand November 2019
"""

import time
import hashlib

# This is the secret passcode, as a string
code = "123"

# Here we create a hash object that holds our secret passcode
# The hashing algorithm is SHA-256 (US FIPS standard)
hashed_code = hashlib.sha256(code.encode())
# The hexdigest() method prints out the hash value as long hex string 
print("hashed_code.hexdigest()\n  ", hashed_code.hexdigest())

# This is the "salt" to further randomize the hash (see the reference)
# Normally the salt would be generated at random to mix things up a bit more
salt = "00"  # This is a string, even if the value looks like an integer

# Create a new hash object with the salt and the passcode concatenated
salted_hash = hashlib.sha256((salt+code).encode())
print("code, salt, salted_hash.hexdigest()\n  ", code, salt, salted_hash.hexdigest())

# When we save the salted and hashed passcode we also must show the salt
# as the first characters of the string. This allows us to reproduce the 
# hashing operation to compare hashed values when checking credentials.
saved_passcode = salt + salted_hash.hexdigest()
print("saved_passcode\n  ", saved_passcode)

# Now we simulate submitting a password and checking hashed values
# This reproduces the original salt + hash procedure.
submitted_passcode = "123"
print("\nSubmitted:\n  ", submitted_passcode)

# Take the first two characters of the stored hash and prepend them to 
# the submitted passcode, prior to hashing.
salted_submitted = saved_passcode[0:2] + submitted_passcode
print("Salt prepended to submitted:\n  ", salted_submitted)

# Hash the salted submitted passcode
submitted_hash = hashlib.sha256(salted_submitted.encode())
print("Hashed salted submitted:\n  ", submitted_hash.hexdigest())
# This next print statement should give you the same as above
print("...and prepend the salt:\n  ", salt + submitted_hash.hexdigest())

# Check the passcode against the stored passcode
if salt + submitted_hash.hexdigest() == saved_passcode:
    print("match!")
else:
    print("NOT matched")

# Done!

