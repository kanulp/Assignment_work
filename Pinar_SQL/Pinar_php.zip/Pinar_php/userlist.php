<html>
<body>
    <h2>Coffee Customer Data:</h2>
<?php 
require('connect.php');

$name = $id ="";

$query = "SELECT * FROM customer where 1";

echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Id</font> </td> 
          <td> <font face="Arial">Name</font> </td> 
          <td> <font face="Arial">Email</font> </td> 
          <td> <font face="Arial">Telephone</font> </td> 
          <td> <font face="Arial">Address</font> </td> 
          <td> <font face="Arial">Zip</font> </td> 
      </tr>';
 $result = mysqli_query($connection, $query);

if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["Id"];
        $field2name = $row["Name"];
        $field3name = $row["Email"];
        $field4name = $row["Telephone"];
        $field5name = $row["Address"]; 
        $field6name = $row["Zip"]; 

 
        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td> 
                    <td>'.$field6name.'</td> 

              </tr>';
    }
    //$result->free();
}else{
    echo 'No data found';
}

function updateUser($id, $name) {
require('connect.php');

    $sql = "Update customer set Name = '$name' where Id = $id ";
    echo $sql;
    if(mysqli_query($connection, $sql)){ 
        echo "Record  successfully updated."; 
    }
    else{ 
         echo "ERROR: Could not able to execute $sql. "  
                                   . mysqli_error($connection); 
    } 
}

function deleteUser($name) {
require('connect.php');

    $sql = "Delete FROM customer where Name = '$name' ";
    echo $sql;
    if(mysqli_query($connection, $sql)){ 
        echo "Record was deleted successfully."; 
    }
    else{ 
         echo "ERROR: Could not able to execute $sql. "  
                                   . mysqli_error($connection); 
    } 
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["id"])) {
        $name = $_POST["name"];
        deleteUser($name);
    }else
    {
        
    }
    if (!empty($_POST["name"]) && !empty($_POST["id"]) ) {
        $id = $_POST["id"];
        $name = $_POST["name"];
        updateUser($id, $name);
    }else
    {
        
    }
}
?>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
    <br/>
    Id:   <input type="text" name="id" value="<?php echo $id;?>"><br>
    Name: <input type="text" name="name" value="<?php echo $name;?>">
  <br><br>
      <input type="submit" name="submit" value="Submit">
      <br/><br/>
</form>

</body>
</html>